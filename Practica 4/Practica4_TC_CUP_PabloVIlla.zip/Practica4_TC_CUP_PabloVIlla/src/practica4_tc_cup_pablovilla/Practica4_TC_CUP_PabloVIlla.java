/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4_tc_cup_pablovilla;

import Practica4_TC_CUP_PabloVilla.parser;
import Practica4_TC_CUP_PabloVilla.analex;

import java_cup.runtime.*;
import java.io.*;

public class Practica4_TC_CUP_PabloVIlla {

    public static void main(String[] args) throws FileNotFoundException, Exception {
       ComplexSymbolFactory csf = new ComplexSymbolFactory();
       ScannerBuffer lexer = new ScannerBuffer(new analex(new BufferedReader(new FileReader(args[0])),csf));
       parser p = new parser(lexer,csf);
       p.parse();
       
       System.out.println("El analisis ha terminado");
    }
}
